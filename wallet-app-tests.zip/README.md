# Wallet App Testing

## Setup
```bash
npm install
```

## Run Unit Tests (Jest)
```bash
npm test
```

## Run E2E Tests (Cypress)
```bash
npm run cypress
```

Make sure your local server is running at `http://localhost:3000` before running Cypress.
