describe('Register Page', () => {
  it('BB01: Show error for short name', () => {
    cy.visit('/pages/register/index.html');
    cy.get('#input-email').type('ana@mail.com');
    cy.get('#input-name').type('Jo');
    cy.contains('Acessar').click();
    cy.on('window:alert', (text) => {
      expect(text).to.contains('Nome deve conter 3 ou mais caracteres');
    });
  });

  it('BB02: Show error for invalid email', () => {
    cy.visit('/pages/register/index.html');
    cy.get('#input-email').type('anamail.com');
    cy.get('#input-name').type('Ana');
    cy.contains('Acessar').click();
    cy.on('window:alert', (text) => {
      expect(text).to.contains('E-mail inválido');
    });
  });

  it('BB03: Register success and redirect', () => {
    cy.visit('/pages/register/index.html');
    cy.get('#input-email').type('ana@mail.com');
    cy.get('#input-name').type('Ana');
    cy.contains('Acessar').click();
    cy.url().should('include', '/home');
    cy.window().then((win) => {
      expect(win.localStorage.getItem('@WalletApp:userEmail')).to.eq('ana@mail.com');
    });
  });
});
