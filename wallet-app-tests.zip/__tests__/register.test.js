import { JSDOM } from 'jsdom';

global.alert = jest.fn();
global.localStorage = {
  setItem: jest.fn()
};
global.open = jest.fn();

const html = `
  <input id="input-email" value="" />
  <input id="input-name" value="" />
  <form id="form-register"></form>
`;

let onRegister;

beforeEach(() => {
  const dom = new JSDOM(html);
  global.document = dom.window.document;
  global.fetch = jest.fn();
  onRegister = require('../assets/index.js').onRegister;
});

test('WB01: Name too short', async () => {
  document.getElementById("input-email").value = "email@mail.com";
  document.getElementById("input-name").value = "Jo";
  await onRegister();
  expect(alert).toHaveBeenCalledWith("Nome deve conter 3 ou mais caracteres!");
});

test('WB02: Invalid email', async () => {
  document.getElementById("input-email").value = "invalidemail.com";
  document.getElementById("input-name").value = "John";
  await onRegister();
  expect(alert).toHaveBeenCalledWith("E-mail inválido.");
});

test('WB03: Valid input, API returns error', async () => {
  document.getElementById("input-email").value = "john@mail.com";
  document.getElementById("input-name").value = "John";
  fetch.mockResolvedValueOnce({
    json: () => Promise.resolve({ error: true })
  });
  await onRegister();
  expect(alert).toHaveBeenCalledWith("Falha na ao cadastrar e-mail");
});

test('WB04: Valid input, success', async () => {
  document.getElementById("input-email").value = "john@mail.com";
  document.getElementById("input-name").value = "John";
  fetch.mockResolvedValueOnce({
    json: () => Promise.resolve({
      email: "john@mail.com",
      name: "John",
      id: "123"
    })
  });
  await onRegister();
  expect(localStorage.setItem).toHaveBeenCalledWith("@WalletApp:userEmail", "john@mail.com");
  expect(global.open).toHaveBeenCalledWith("../home/index.html", "_self");
});
